<section class="footer">

   <div class="box-container">

      <div class="box">
         <h3>quick links</h3>
         <a href="home.php">home</a>
         <a href="shop.php">shop</a>
         <a href="contact.php">contact</a>
      </div>

      <div class="box">
         <h3>extra links</h3>
         <a href="login.php">login</a>
         <a href="register.php">register</a>
      </div>

      <div class="box">
         <h3>contact info</h3>
         <p>  +91-7349578029 </p>
		 <p> sushmitha2002@gmail.com </p>
		 <p>  vidya7349@gmail.com  </p>
         <p>  Mangalore,India - 575001 </p>
      </div>
	  
	   <div class="box">
         <h3>follow us</h3>
          <a href="https://www.instagram.com/__happy__hoops__?igsh=aXl4azIwd2c5cTk2">happy_hoops</a>
      </div>

   </div>
</section>